// =============================================================================
// BDSGP 后台管理系统 - JavaScript 功能实现
// =============================================================================

import { API_CONFIG } from '../js/config.js';
import ADMIN_CONFIG from './admin-config.js';

// API基础地址
const API_BASE_URL = ADMIN_CONFIG.apiBaseUrl;

// 管理员密钥（从配置文件中获取）
let ADMIN_KEY = ADMIN_CONFIG.adminKey;

// 当前Token（从配置文件中获取）
let CURRENT_TOKEN = ADMIN_CONFIG.defaultToken;

// DOM元素
const elements = {
    // 导航链接
    navLinks: document.querySelectorAll('.nav-link'),

    // 管理部分
    sections: document.querySelectorAll('.admin-section'),

    // 控制面板元素
    totalServers: document.getElementById('total-servers'),
    onlineServers: document.getElementById('online-servers'),
    totalTokens: document.getElementById('total-tokens'),
    todayAdded: document.getElementById('today-added'),
    recentServers: document.getElementById('recent-servers'),

    // 服务器管理元素
    addServerBtn: document.getElementById('add-server-btn'),
    refreshServersBtn: document.getElementById('refresh-servers-btn'),
    serverSearch: document.getElementById('server-search'),
    serverStatusFilter: document.getElementById('server-status-filter'),
    serversTbody: document.getElementById('servers-tbody'),

    // Token管理元素
    addTokenBtn: document.getElementById('add-token-btn'),
    refreshTokensBtn: document.getElementById('refresh-tokens-btn'),
    tokenSearch: document.getElementById('token-search'),
    tokensTbody: document.getElementById('tokens-tbody'),

    // 管理员功能元素
    adminRefreshBtn: document.getElementById('admin-refresh-btn'),
    adminDeleteUuid: document.getElementById('admin-delete-uuid'),
    adminDeleteBtn: document.getElementById('admin-delete-btn'),
    adminEditUuid: document.getElementById('admin-edit-uuid'),
    adminEditName: document.getElementById('admin-edit-name'),
    adminEditIntroduce: document.getElementById('admin-edit-introduce'),
    adminEditHost: document.getElementById('admin-edit-host'),
    adminEditPort: document.getElementById('admin-edit-port'),
    adminEditToken: document.getElementById('admin-edit-token'),
    adminEditBtn: document.getElementById('admin-edit-btn'),

    // 模态框
    addServerModal: document.getElementById('add-server-modal'),
    addTokenModal: document.getElementById('add-token-modal'),
    editServerModal: document.getElementById('edit-server-modal'),
    modals: document.querySelectorAll('.modal'),

    // 表单
    addServerForm: document.getElementById('add-server-form'),
    addTokenForm: document.getElementById('add-token-form'),
    editServerForm: document.getElementById('edit-server-form'),

    // 其他
    logoutBtn: document.getElementById('logout-btn'),
    notification: document.getElementById('notification')
};

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    // 检查调试模式
    if (ADMIN_CONFIG.debug) {
        console.log('[调试模式] 已启用调试模式');
        console.log('[调试模式] 管理员密钥:', ADMIN_KEY);
        console.log('[调试模式] 默认Token:', CURRENT_TOKEN);
    }

    // 检查登录状态
    checkLoginStatus();

    // 设置导航事件
    setupNavigation();

    // 设置模态框事件
    setupModals();

    // 设置表单事件
    setupForms();

    // 设置按钮事件
    setupButtons();

    // 设置搜索和筛选事件
    setupFilters();

    // 加载控制面板数据
    loadDashboardData();
});

// 检查登录状态
function checkLoginStatus() {
    // 在实际应用中，这里应该检查用户是否已登录
    // 如果未登录，应该重定向到登录页面
    // 这里我们假设用户已经登录
    console.log('用户已登录');
}

// 设置导航
function setupNavigation() {
    elements.navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();

            // 移除所有活动状态
            elements.navLinks.forEach(l => l.classList.remove('active'));
            elements.sections.forEach(s => s.classList.remove('active'));

            // 添加活动状态
            link.classList.add('active');
            const sectionId = link.getAttribute('data-section');
            document.getElementById(sectionId).classList.add('active');

            // 根据导航加载相应数据
            switch(sectionId) {
                case 'dashboard':
                    loadDashboardData();
                    break;
                case 'servers':
                    loadServersData();
                    break;
                case 'tokens':
                    loadTokensData();
                    break;
            }
        });
    });
}

// 设置模态框
function setupModals() {
    // 关闭按钮
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', (e) => {
            e.target.closest('.modal').style.display = 'none';
        });
    });

    // 点击模态框外部关闭
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });

    // 取消按钮
    document.querySelectorAll('.cancel-btn').forEach(cancelBtn => {
        cancelBtn.addEventListener('click', () => {
            cancelBtn.closest('.modal').style.display = 'none';
        });
    });
}

// 设置表单
function setupForms() {
    // 添加服务器表单
    elements.addServerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        addServer();
    });

    // 添加Token表单
    elements.addTokenForm.addEventListener('submit', (e) => {
        e.preventDefault();
        addToken();
    });

    // 编辑服务器表单
    elements.editServerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        updateServer();
    });
}

// 设置按钮
function setupButtons() {
    // 添加服务器按钮
    elements.addServerBtn.addEventListener('click', () => {
        elements.addServerModal.style.display = 'block';
    });

    // 刷新服务器列表按钮
    elements.refreshServersBtn.addEventListener('click', loadServersData);

    // 添加Token按钮
    elements.addTokenBtn.addEventListener('click', () => {
        elements.addTokenModal.style.display = 'block';
    });

    // 刷新Token列表按钮
    elements.refreshTokensBtn.addEventListener('click', loadTokensData);

    // 刷新数据按钮
    elements.adminRefreshBtn.addEventListener('click', () => {
        loadDashboardData();
        loadServersData();
        loadTokensData();
        showNotification('数据已刷新', 'success');
    });

    // 管理员删除按钮
    elements.adminDeleteBtn.addEventListener('click', deleteServerByAdmin);

    // 管理员编辑按钮
    elements.adminEditBtn.addEventListener('click', updateServerByAdmin);

    // 退出登录按钮
    elements.logoutBtn.addEventListener('click', () => {
        // 在实际应用中，这里应该清除登录状态
        showNotification('已退出登录', 'info');
        // 然后重定向到登录页面
        // window.location.href = 'login.html';
    });
}

// 设置筛选和搜索
function setupFilters() {
    // 服务器搜索
    elements.serverSearch.addEventListener('input', filterServers);

    // 服务器状态筛选
    elements.serverStatusFilter.addEventListener('change', filterServers);

    // Token搜索
    elements.tokenSearch.addEventListener('input', filterTokens);
}

// 加载控制面板数据
function loadDashboardData() {
    // 获取服务器总数
    fetch(`${API_BASE_URL}/get`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const servers = data.data;
                elements.totalServers.textContent = servers.length;

                // 计算在线服务器数量
                const onlineCount = servers.filter(s => s.online).length;
                elements.onlineServers.textContent = onlineCount;

                // 获取最近添加的服务器
                const recentServers = servers.slice(0, 5);
                displayRecentServers(recentServers);
            }
        })
        .catch(error => {
            console.error('获取服务器数据失败:', error);
            showNotification('获取服务器数据失败', 'error');
        });

    // 获取Token数量（这里使用模拟数据，实际API可能没有这个接口）
    elements.totalTokens.textContent = '12';

    // 获取今日添加数量（这里使用模拟数据，实际API可能没有这个接口）
    elements.todayAdded.textContent = '3';
}

// 显示最近添加的服务器
function displayRecentServers(servers) {
    elements.recentServers.innerHTML = '';

    if (servers.length === 0) {
        elements.recentServers.innerHTML = '<p class="no-data">暂无数据</p>';
        return;
    }

    servers.forEach(server => {
        const item = document.createElement('div');
        item.className = 'recent-server-item';
        item.innerHTML = `
            <div>
                <strong>${server.name}</strong>
                <span class="status-badge ${server.online ? 'status-online' : 'status-offline'}">
                    ${server.online ? '在线' : '离线'}
                </span>
            </div>
            <div>${server.player_count} 玩家在线</div>
        `;
        elements.recentServers.appendChild(item);
    });
}

// 加载服务器数据
function loadServersData() {
    elements.serversTbody.innerHTML = '<tr><td colspan="8" class="loading">加载中...</td></tr>';

    fetch(`${API_BASE_URL}/get`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                displayServers(data.data);
            } else {
                showNotification('获取服务器数据失败: ' + data.message, 'error');
                elements.serversTbody.innerHTML = '<tr><td colspan="8" class="error">加载失败</td></tr>';
            }
        })
        .catch(error => {
            console.error('获取服务器数据失败:', error);
            showNotification('获取服务器数据失败', 'error');
            elements.serversTbody.innerHTML = '<tr><td colspan="8" class="error">加载失败</td></tr>';
        });
}

// 显示服务器列表
function displayServers(servers) {
    elements.serversTbody.innerHTML = '';

    if (servers.length === 0) {
        elements.serversTbody.innerHTML = '<tr><td colspan="8" class="no-data">暂无数据</td></tr>';
        return;
    }

    servers.forEach(server => {
        const row = document.createElement('tr');
        row.setAttribute('data-uuid', server.uuid);
        row.setAttribute('data-status', server.online ? 'online' : 'offline');
        row.innerHTML = `
            <td class="uuid-cell">${server.uuid.substring(0, 8)}...</td>
            <td>${server.name}</td>
            <td>${server.host}</td>
            <td>${server.port}</td>
            <td>
                <span class="status-badge ${server.online ? 'status-online' : 'status-offline'}">
                    ${server.online ? '在线' : '离线'}
                </span>
            </td>
            <td>${server.online ? server.player_count : '-'}</td>
            <td>${server.last_status_time}</td>
            <td>
                <button class="btn btn-sm btn-primary edit-btn" data-uuid="${server.uuid}">编辑</button>
                <button class="btn btn-sm btn-danger delete-btn" data-uuid="${server.uuid}">删除</button>
            </td>
        `;
        elements.serversTbody.appendChild(row);
    });

    // 添加编辑和删除按钮事件
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const uuid = e.target.getAttribute('data-uuid');
            loadServerForEdit(uuid);
        });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const uuid = e.target.getAttribute('data-uuid');
            deleteServer(uuid);
        });
    });
}

// 加载服务器数据用于编辑
function loadServerForEdit(uuid) {
    fetch(`${API_BASE_URL}/get?uuid=${uuid}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const server = data.data;
                document.getElementById('edit-server-uuid').value = server.uuid;
                document.getElementById('edit-server-name').value = server.name;
                document.getElementById('edit-server-introduce').value = server.introduce;
                document.getElementById('edit-server-host').value = server.host;
                document.getElementById('edit-server-port').value = server.port;
                elements.editServerModal.style.display = 'block';
            } else {
                showNotification('加载服务器数据失败: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('加载服务器数据失败:', error);
            showNotification('加载服务器数据失败', 'error');
        });
}

// 添加服务器
function addServer() {
    const name = document.getElementById('server-name').value;
    const introduce = document.getElementById('server-introduce').value;
    const host = document.getElementById('server-host').value;
    const port = document.getElementById('server-port').value;
    const token = document.getElementById('server-token').value || CURRENT_TOKEN;

    const formData = new FormData();
    formData.append('name', name);
    formData.append('introduce', introduce);
    formData.append('host', host);
    formData.append('port', port);

    fetch(`${API_BASE_URL}/post`, {
        method: 'POST',
        headers: {
            'token': token,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('服务器添加成功', 'success');
            elements.addServerModal.style.display = 'none';
            elements.addServerForm.reset();
            loadServersData();
            loadDashboardData();
        } else {
            showNotification('添加服务器失败: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('添加服务器失败:', error);
        showNotification('添加服务器失败', 'error');
    });
}

// 更新服务器
function updateServer() {
    const uuid = document.getElementById('edit-server-uuid').value;
    const name = document.getElementById('edit-server-name').value;
    const introduce = document.getElementById('edit-server-introduce').value;
    const host = document.getElementById('edit-server-host').value;
    const port = document.getElementById('edit-server-port').value;

    // 构建请求数据
    const data = {
        uuid: uuid
    };

    if (name) data.name = name;
    if (introduce) data.introduce = introduce;
    if (host) data.host = host;
    if (port) data.port = port;

    if (Object.keys(data).length <= 1) {
        showNotification('请至少修改一个字段', 'warning');
        return;
    }

    fetch(`${API_BASE_URL}/update`, {
        method: 'POST',
        headers: {
            'token': CURRENT_TOKEN,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.status === 'success') {
            showNotification('服务器更新成功', 'success');
            elements.editServerModal.style.display = 'none';
            loadServersData();
        } else {
            showNotification('更新服务器失败: ' + result.message, 'error');
        }
    })
    .catch(error => {
        console.error('更新服务器失败:', error);
        showNotification('更新服务器失败', 'error');
    });
}

// 删除服务器
function deleteServer(uuid) {
    if (!confirm('确定要删除这个服务器吗？此操作不可撤销。')) {
        return;
    }

    fetch(`${API_BASE_URL}/delete`, {
        method: 'POST',
        headers: {
            'token': CURRENT_TOKEN,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `uuid=${uuid}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('服务器删除成功', 'success');
            loadServersData();
            loadDashboardData();
        } else {
            showNotification('删除服务器失败: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('删除服务器失败:', error);
        showNotification('删除服务器失败', 'error');
    });
}

// 加载Token数据
function loadTokensData() {
    // 由于API没有提供获取Token列表的接口，这里使用模拟数据
    const mockTokens = [
        { token: 'f47ac10b-58cc-4372-a567-0e02b2c3d479', serverCount: 3, createTime: '2023-01-15', lastUse: '2023-01-20' },
        { token: '550e8400-e29b-41d4-a716-446655440000', serverCount: 2, createTime: '2023-02-10', lastUse: '2023-02-18' },
        { token: '6ba7b810-9dad-11d1-80b4-00c04fd430c8', serverCount: 1, createTime: '2023-03-05', lastUse: '2023-03-10' }
    ];

    displayTokens(mockTokens);
}

// 显示Token列表
function displayTokens(tokens) {
    elements.tokensTbody.innerHTML = '';

    if (tokens.length === 0) {
        elements.tokensTbody.innerHTML = '<tr><td colspan="5" class="no-data">暂无数据</td></tr>';
        return;
    }

    tokens.forEach(token => {
        const row = document.createElement('tr');
        row.setAttribute('data-token', token.token);
        row.innerHTML = `
            <td class="token-cell">${token.token.substring(0, 8)}...</td>
            <td>${token.serverCount}</td>
            <td>${token.createTime}</td>
            <td>${token.lastUse}</td>
            <td>
                <button class="btn btn-sm btn-danger delete-token-btn" data-token="${token.token}">删除</button>
            </td>
        `;
        elements.tokensTbody.appendChild(row);
    });

    // 添加删除Token按钮事件
    document.querySelectorAll('.delete-token-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const token = e.target.getAttribute('data-token');
            deleteToken(token);
        });
    });
}

// 添加Token
function addToken() {
    const token = document.getElementById('new-token').value;

    fetch(`${API_BASE_URL}/admin/token`, {
        method: 'POST',
        headers: {
            'Admin-Key': ADMIN_KEY,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `operation=add&token=${token || ''}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('Token添加成功: ' + data.token, 'success');
            elements.addTokenModal.style.display = 'none';
            elements.addTokenForm.reset();
            loadTokensData();
        } else {
            showNotification('添加Token失败: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('添加Token失败:', error);
        showNotification('添加Token失败', 'error');
    });
}

// 删除Token
function deleteToken(token) {
    if (!confirm('确定要删除这个Token吗？此操作不可撤销。')) {
        return;
    }

    fetch(`${API_BASE_URL}/admin/token`, {
        method: 'POST',
        headers: {
            'Admin-Key': ADMIN_KEY,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `operation=delete&token=${token}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('Token删除成功', 'success');
            loadTokensData();
        } else {
            showNotification('删除Token失败: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('删除Token失败:', error);
        showNotification('删除Token失败', 'error');
    });
}

// 使用管理员权限删除服务器
function deleteServerByAdmin() {
    const uuid = elements.adminDeleteUuid.value.trim();

    if (!uuid) {
        showNotification('请输入要删除的服务器UUID', 'warning');
        return;
    }

    if (!confirm('确定要使用管理员权限删除这个服务器吗？此操作不可撤销。')) {
        return;
    }

    fetch(`${API_BASE_URL}/admin/delete_data`, {
        method: 'POST',
        headers: {
            'Admin-Key': ADMIN_KEY,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `uuid=${uuid}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('服务器删除成功', 'success');
            elements.adminDeleteUuid.value = '';
            loadServersData();
            loadDashboardData();
        } else {
            showNotification('删除服务器失败: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('删除服务器失败:', error);
        showNotification('删除服务器失败', 'error');
    });
}

// 使用管理员权限更新服务器
function updateServerByAdmin() {
    const uuid = elements.adminEditUuid.value.trim();
    const name = elements.adminEditName.value.trim();
    const introduce = elements.adminEditIntroduce.value.trim();
    const host = elements.adminEditHost.value.trim();
    const port = elements.adminEditPort.value.trim();
    const token = elements.adminEditToken.value.trim();

    if (!uuid) {
        showNotification('请输入要修改的服务器UUID', 'warning');
        return;
    }

    // 构建请求数据
    const data = {
        uuid: uuid
    };

    if (name) data.name = name;
    if (introduce) data.introduce = introduce;
    if (host) data.host = host;
    if (port) data.port = port;
    if (token) data.token = token;

    if (Object.keys(data).length <= 1) {
        showNotification('请至少修改一个字段', 'warning');
        return;
    }

    fetch(`${API_BASE_URL}/admin/update_data`, {
        method: 'POST',
        headers: {
            'Admin-Key': ADMIN_KEY,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.status === 'success') {
            showNotification('服务器更新成功', 'success');
            // 清空表单
            elements.adminEditUuid.value = '';
            elements.adminEditName.value = '';
            elements.adminEditIntroduce.value = '';
            elements.adminEditHost.value = '';
            elements.adminEditPort.value = '';
            elements.adminEditToken.value = '';
            loadServersData();
        } else {
            showNotification('更新服务器失败: ' + result.message, 'error');
        }
    })
    .catch(error => {
        console.error('更新服务器失败:', error);
        showNotification('更新服务器失败', 'error');
    });
}

// 筛选服务器
function filterServers() {
    const searchTerm = elements.serverSearch.value.toLowerCase();
    const statusFilter = elements.serverStatusFilter.value;

    const rows = elements.serversTbody.querySelectorAll('tr');

    rows.forEach(row => {
        const uuid = row.querySelector('.uuid-cell').textContent.toLowerCase();
        const name = row.cells[1].textContent.toLowerCase();
        const host = row.cells[2].textContent.toLowerCase();
        const status = row.getAttribute('data-status');

        const matchesSearch = uuid.includes(searchTerm) || name.includes(searchTerm) || host.includes(searchTerm);
        const matchesStatus = statusFilter === 'all' || status === statusFilter;

        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
    });
}

// 筛选Token
function filterTokens() {
    const searchTerm = elements.tokenSearch.value.toLowerCase();

    const rows = elements.tokensTbody.querySelectorAll('tr');

    rows.forEach(row => {
        const token = row.querySelector('.token-cell').textContent.toLowerCase();

        row.style.display = token.includes(searchTerm) ? '' : 'none';
    });
}

// 显示通知
function showNotification(message, type = 'info') {
    elements.notification.textContent = message;
    elements.notification.className = `notification ${type}`;
    elements.notification.style.display = 'block';

    // 3秒后自动隐藏
    setTimeout(() => {
        elements.notification.style.display = 'none';
    }, 3000);
}
