// =============================================================================
// BDSGP 后台管理系统 - 配置文件
// =============================================================================

/**
 * 管理员配置
 * 包含管理员密钥、默认Token等敏感信息
 * 在实际应用中，这些信息应该从安全的地方获取，而不是直接写在代码中
 */
const ADMIN_CONFIG = {
    // 管理员密钥（用于管理员接口）
    adminKey: "HhhdGhjHfGhHbgGzdhgGgUhfghjygcj",

    // 默认Token（用于普通用户操作）
    defaultToken: "0f84ad03-be54-4797-918e-d2784f3a3301",

    // API基础地址
    apiBaseUrl: "https://api.bdsgp.cn",

    // 是否启用调试模式
    debug: true
};

// 导出配置
export default ADMIN_CONFIG;
